// ─── MOCK DATA ────────────────────────────────────────────────────────────────
export const MOCK_USER = {
  email: "admin@quantix.io",
  password: "admin123",
  name: "Alex Morgan",
  role: "Super Admin",
  company: "Quantix Labs",
};

export const revenueData = [
  { month: "Jan", revenue: 42000, expenses: 28000 },
  { month: "Feb", revenue: 55000, expenses: 32000 },
  { month: "Mar", revenue: 48000, expenses: 29000 },
  { month: "Apr", revenue: 61000, expenses: 35000 },
  { month: "May", revenue: 73000, expenses: 38000 },
  { month: "Jun", revenue: 68000, expenses: 41000 },
  { month: "Jul", revenue: 82000, expenses: 44000 },
];

export const trafficData = [
  { day: "Mon", organic: 3200, paid: 1800, direct: 900 },
  { day: "Tue", organic: 2800, paid: 2200, direct: 1100 },
  { day: "Wed", organic: 4100, paid: 1900, direct: 800 },
  { day: "Thu", organic: 3700, paid: 2500, direct: 1400 },
  { day: "Fri", organic: 4800, paid: 2100, direct: 1200 },
  { day: "Sat", organic: 2100, paid: 1200, direct: 600 },
  { day: "Sun", organic: 1800, paid: 900, direct: 500 },
];

export const pieData = [
  { name: "Enterprise", value: 38, color: "#6366f1" },
  { name: "Pro", value: 29, color: "#8b5cf6" },
  { name: "Starter", value: 21, color: "#a78bfa" },
  { name: "Free", value: 12, color: "#c4b5fd" },
];

export const aiUsageData = [
  { week: "W1", queries: 12400, tokens: 8200 },
  { week: "W2", queries: 15800, tokens: 11200 },
  { week: "W3", queries: 13200, tokens: 9400 },
  { week: "W4", queries: 18900, tokens: 14200 },
  { week: "W5", queries: 22100, tokens: 17800 },
  { week: "W6", queries: 19500, tokens: 15200 },
];

export const initialLeads = [
  { id: 1, name: "Sarah Chen", company: "Vertex Corp", email: "s.chen@vertex.io", status: "Hot", value: 48000, date: "2024-07-15" },
  { id: 2, name: "James Whitfield", company: "Meridian Labs", email: "j.white@meridian.com", status: "Warm", value: 23500, date: "2024-07-12" },
  { id: 3, name: "Priya Nair", company: "Solaris AI", email: "p.nair@solaris.ai", status: "Cold", value: 12000, date: "2024-07-10" },
  { id: 4, name: "Marcus Reyes", company: "Cobalt Tech", email: "m.reyes@cobalt.tech", status: "Hot", value: 67000, date: "2024-07-08" },
  { id: 5, name: "Elena Vasquez", company: "Neon Digital", email: "e.vasquez@neon.io", status: "Warm", value: 31000, date: "2024-07-05" },
  { id: 6, name: "Tom Nakamura", company: "Pulse Systems", email: "t.naka@pulse.sys", status: "Qualified", value: 55000, date: "2024-07-03" },
];

export const initialProjects = [
  { id: 1, name: "Quantix Analytics v2", status: "In Progress", progress: 72, team: ["AK", "SR", "MJ"], due: "Aug 15", priority: "High" },
  { id: 2, name: "Mobile App Redesign", status: "Review", progress: 91, team: ["PL", "TR"], due: "Jul 28", priority: "Critical" },
  { id: 3, name: "API Gateway Migration", status: "In Progress", progress: 44, team: ["NK", "BJ", "CR", "LM"], due: "Sep 02", priority: "Medium" },
  { id: 4, name: "Customer Portal", status: "Planning", progress: 18, team: ["AM", "DS"], due: "Sep 30", priority: "Low" },
];

export const initialKanban = {
  todo: [
    { id: "t1", title: "Research competitor analytics", tag: "Research", priority: "Medium" },
    { id: "t2", title: "Design new onboarding flow", tag: "Design", priority: "High" },
    { id: "t3", title: "Update API documentation", tag: "Docs", priority: "Low" },
  ],
  inprogress: [
    { id: "t4", title: "Build reporting module", tag: "Dev", priority: "High" },
    { id: "t5", title: "QA testing sprint 4", tag: "Testing", priority: "Critical" },
  ],
  review: [
    { id: "t6", title: "Accessibility audit", tag: "QA", priority: "Medium" },
  ],
  done: [
    { id: "t7", title: "Set up CI/CD pipeline", tag: "DevOps", priority: "High" },
    { id: "t8", title: "User interviews (12 sessions)", tag: "Research", priority: "Medium" },
  ],
};

export const initialEmails = {
  inbox: [
    { id: "e1", from: "Sarah Chen", subject: "Q3 Proposal Follow-up", preview: "Hi, just checking in on the proposal we discussed...", date: "10:32 AM", read: false, starred: false },
    { id: "e2", from: "Stripe", subject: "Your invoice is ready", preview: "Invoice #INV-2024-0847 for $1,240.00 is now available...", date: "9:15 AM", read: false, starred: false },
    { id: "e3", from: "Marcus Reyes", subject: "Partnership opportunity", preview: "We'd love to explore a potential integration between...", date: "Yesterday", read: true, starred: true },
    { id: "e4", from: "GitHub", subject: "Security alert on quantix-api", preview: "A vulnerability was detected in one of your dependencies...", date: "Yesterday", read: true, starred: false },
  ],
  sent: [],
  drafts: [],
  starred: [],
  trash: [],
};

export const initialNotifications = [
  { id: 1, text: "New lead added: Sarah Chen from Vertex Corp", time: "2m ago", read: false, icon: "👤" },
  { id: 2, text: "Revenue target 85% achieved this month", time: "1h ago", read: false, icon: "📈" },
  { id: 3, text: "Project 'Mobile App Redesign' moved to Review", time: "3h ago", read: false, icon: "📋" },
  { id: 4, text: "New comment on Analytics Dashboard ticket", time: "5h ago", read: true, icon: "💬" },
  { id: 5, text: "Scheduled maintenance: Sunday 2-4 AM UTC", time: "1d ago", read: true, icon: "🔧" },
];

export const chatConversations = [
  {
    id: "c1",
    title: "Revenue analysis deep dive",
    messages: [
      { role: "user", content: "Analyze our Q2 revenue trends and suggest improvements." },
      { role: "ai", content: "Based on the data patterns, Q2 showed **18% growth** over Q1, primarily driven by enterprise tier upgrades. Key observations:\n\n1. **Enterprise segment** grew 31% — your highest performer\n2. **Churn rate** decreased from 4.2% to 2.8%\n3. **ARPU** increased by $24 MoM\n\nRecommended focus areas: expand enterprise upsell motions and invest in the onboarding flow to reduce time-to-value for new Pro users." },
    ],
  },
  {
    id: "c2",
    title: "Product roadmap planning",
    messages: [
      { role: "user", content: "Help me prioritize our product roadmap for Q4." },
      { role: "ai", content: "For Q4 prioritization, I'd recommend using the **ICE framework** (Impact, Confidence, Effort).\n\nBased on your current metrics, the highest-priority items would be:\n\n- **AI-powered insights** — high demand, strong differentiation\n- **Mobile app** — 40% of users request this\n- **API v2** — unblocks 3 enterprise deals\n\nShall I create a detailed scoring matrix?" },
    ],
  },
];

// ─── UTILITIES ────────────────────────────────────────────────────────────────
export const fmt = (n: number) =>
  n >= 1000000 ? `$${(n / 1000000).toFixed(1)}M` : n >= 1000 ? `$${(n / 1000).toFixed(0)}K` : `$${n}`;

export const fmtNum = (n: number) =>
  n >= 1000000 ? `${(n / 1000000).toFixed(1)}M` : n >= 1000 ? `${(n / 1000).toFixed(0)}K` : String(n);

export const uid = () => Math.random().toString(36).slice(2, 8);
