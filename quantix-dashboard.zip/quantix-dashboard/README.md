# Quantix UI — Admin Analytics Dashboard

A fully-featured SaaS admin dashboard built with Next.js 14, TypeScript, and Recharts.

## Features

- 🔐 **Authentication** — Login, Register, Forgot Password (demo: `admin@quantix.io` / `admin123`)
- 🤖 **AI Dashboard** — KPI cards, AI usage charts, activity feed
- 📊 **Analytics** — Revenue, traffic, area & bar charts with CSV export
- 👥 **CRM / Leads** — Searchable lead table with CRUD and pagination
- 💰 **Finance** — Invoice management, revenue charts, pie chart
- 🗂️ **Projects** — Project cards with progress bars and team avatars
- 📋 **Kanban** — Drag-and-drop board with column management
- 📅 **Calendar** — Monthly calendar with event creation/deletion
- 💬 **AI Chat** — Mock AI assistant with conversation history
- 📧 **Email** — Full email client with compose, drafts, trash, starring
- ⚙️ **Settings** — Profile editor, billing plans, payment methods
- 🌙 **Dark/Light mode** — Persistent theme toggle
- 📱 **Responsive** — Mobile-optimized sidebar

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Language**: TypeScript
- **Charts**: Recharts
- **Styling**: Custom CSS with CSS variables (dark/light themes)
- **Fonts**: Plus Jakarta Sans + JetBrains Mono

## Local Development

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Open http://localhost:3000
```

## Deploy to Vercel

### Option 1: Vercel CLI
```bash
npm i -g vercel
vercel
```

### Option 2: GitHub + Vercel Dashboard
1. Push this project to a GitHub repository
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repository
4. Vercel auto-detects Next.js — click **Deploy**

### Option 3: Drag & Drop
1. Run `npm run build` locally
2. Drag the project folder to [vercel.com/new](https://vercel.com/new)

## Demo Credentials

```
Email: admin@quantix.io
Password: admin123
```

## Project Structure

```
quantix-dashboard/
├── app/
│   ├── globals.css        # All styles (CSS variables, dark/light)
│   ├── layout.tsx         # Root HTML layout
│   └── page.tsx           # Entry point
├── components/
│   └── App.tsx            # Full app (all pages & components)
├── lib/
│   └── data.ts            # Mock data & utility functions
├── next.config.js
├── package.json
├── tsconfig.json
└── vercel.json
```
