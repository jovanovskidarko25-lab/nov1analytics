"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend
} from "recharts";
import {
  MOCK_USER, revenueData, trafficData, pieData, aiUsageData,
  initialLeads, initialProjects, initialKanban, initialEmails,
  initialNotifications, chatConversations, fmt, fmtNum, uid
} from "@/lib/data";

// ─── TOAST ────────────────────────────────────────────────────────────────────
function useToast() {
  const [toasts, setToasts] = useState<{id:string;msg:string;type:string}[]>([]);
  const add = useCallback((msg: string, type = "success") => {
    const id = uid();
    setToasts(p => [...p, { id, msg, type }]);
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3500);
  }, []);
  return { toasts, add };
}

function ToastContainer({ toasts }: { toasts: {id:string;msg:string;type:string}[] }) {
  return (
    <div className="toast-container">
      {toasts.map(t => (
        <div key={t.id} className={`toast toast-${t.type}`}>
          <span>{t.type === "success" ? "✅" : t.type === "error" ? "❌" : "ℹ️"}</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  );
}

// ─── AUTH PAGES ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin, onNavigate }: { onLogin: () => void; onNavigate: (p: string) => void }) {
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = () => {
    if (!form.email || !form.password) { setError("Please fill in all fields."); return; }
    setLoading(true); setError("");
    setTimeout(() => {
      if (form.email === MOCK_USER.email && form.password === MOCK_USER.password) {
        localStorage.setItem("qx_session", JSON.stringify({ email: form.email, name: MOCK_USER.name }));
        onLogin();
      } else {
        setError("Invalid email or password."); setLoading(false);
      }
    }, 800);
  };

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo">
          <div className="brand-icon">✦</div>
          <div>
            <div className="brand-name">Quantix UI</div>
            <div style={{fontSize:10,color:"var(--text3)"}}>Admin Analytics Hub</div>
          </div>
        </div>
        <div className="auth-title">Welcome back</div>
        <div className="auth-sub">Sign in to your dashboard</div>
        {error && <div className="auth-error">{error}</div>}
        <div className="form-group">
          <label className="form-label">Email address</label>
          <input className="form-input" type="email" placeholder="admin@quantix.io" value={form.email} onChange={e=>setForm(p=>({...p,email:e.target.value}))} onKeyDown={e=>e.key==="Enter"&&handleSubmit()} />
        </div>
        <div className="form-group">
          <label className="form-label">Password</label>
          <input className="form-input" type="password" placeholder="••••••••" value={form.password} onChange={e=>setForm(p=>({...p,password:e.target.value}))} onKeyDown={e=>e.key==="Enter"&&handleSubmit()} />
        </div>
        <div style={{textAlign:"right",marginBottom:16}}>
          <span className="auth-link text-sm" onClick={()=>onNavigate("forgot")}>Forgot password?</span>
        </div>
        <button className="btn btn-primary w-full" onClick={handleSubmit} disabled={loading} style={{justifyContent:"center",height:40}}>
          {loading ? "Signing in…" : "Sign in"}
        </button>
        <div className="auth-divider">or</div>
        <div className="text-sm" style={{textAlign:"center",color:"var(--text2)"}}>
          Don&apos;t have an account? <span className="auth-link" onClick={()=>onNavigate("register")}>Create one</span>
        </div>
        <div className="auth-success" style={{marginTop:16,marginBottom:0}}>
          <strong>Demo:</strong> admin@quantix.io / admin123
        </div>
      </div>
    </div>
  );
}

function RegisterPage({ onNavigate }: { onNavigate: (p: string) => void }) {
  const [form, setForm] = useState({ name:"", email:"", password:"", confirm:"" });
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [success, setSuccess] = useState(false);

  const validate = () => {
    const e: Record<string,string> = {};
    if (!form.name) e.name = "Name is required";
    if (!form.email || !/\S+@\S+\.\S+/.test(form.email)) e.email = "Valid email required";
    if (!form.password || form.password.length < 6) e.password = "Min 6 characters";
    if (form.password !== form.confirm) e.confirm = "Passwords don't match";
    return e;
  };

  const handleSubmit = () => {
    const e = validate(); setErrors(e);
    if (Object.keys(e).length === 0) setSuccess(true);
  };

  if (success) return (
    <div className="auth-page">
      <div className="auth-card" style={{textAlign:"center"}}>
        <div style={{fontSize:48,marginBottom:16}}>🎉</div>
        <div className="auth-title">Account created!</div>
        <div className="auth-sub" style={{marginBottom:20}}>Your account is ready. Sign in to continue.</div>
        <button className="btn btn-primary w-full" onClick={()=>onNavigate("login")} style={{justifyContent:"center"}}>Go to login</button>
      </div>
    </div>
  );

  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo"><div className="brand-icon">✦</div><div className="brand-name">Quantix UI</div></div>
        <div className="auth-title">Create account</div>
        <div className="auth-sub">Start your 14-day free trial</div>
        {(["name","email","password","confirm"] as const).map(f => (
          <div className="form-group" key={f}>
            <label className="form-label">{f==="confirm"?"Confirm password":f.charAt(0).toUpperCase()+f.slice(1)}</label>
            <input className="form-input" type={f.includes("pass")||f==="confirm"?"password":"text"} placeholder={f==="name"?"Alex Morgan":f==="email"?"you@company.com":"••••••••"} value={form[f]} onChange={e=>setForm(p=>({...p,[f]:e.target.value}))} />
            {errors[f] && <div className="form-error">{errors[f]}</div>}
          </div>
        ))}
        <button className="btn btn-primary w-full" onClick={handleSubmit} style={{justifyContent:"center",height:40}}>Create account</button>
        <div className="auth-divider">or</div>
        <div className="text-sm" style={{textAlign:"center",color:"var(--text2)"}}>
          Already have an account? <span className="auth-link" onClick={()=>onNavigate("login")}>Sign in</span>
        </div>
      </div>
    </div>
  );
}

function ForgotPage({ onNavigate }: { onNavigate: (p: string) => void }) {
  const [email, setEmail] = useState("");
  const [sent, setSent] = useState(false);
  return (
    <div className="auth-page">
      <div className="auth-card">
        <div className="auth-logo"><div className="brand-icon">✦</div><div className="brand-name">Quantix UI</div></div>
        <div className="auth-title">Reset password</div>
        <div className="auth-sub">We&apos;ll send you a reset link</div>
        {sent ? (
          <div className="auth-success">Reset link sent to <strong>{email}</strong>. Check your inbox.</div>
        ) : (
          <>
            <div className="form-group">
              <label className="form-label">Email address</label>
              <input className="form-input" type="email" placeholder="admin@quantix.io" value={email} onChange={e=>setEmail(e.target.value)} />
            </div>
            <button className="btn btn-primary w-full" onClick={()=>email&&setSent(true)} style={{justifyContent:"center",height:40}}>Send reset link</button>
          </>
        )}
        <div className="text-sm" style={{marginTop:14,textAlign:"center",color:"var(--text2)"}}>
          <span className="auth-link" onClick={()=>onNavigate("login")}>← Back to login</span>
        </div>
      </div>
    </div>
  );
}

// ─── SIDEBAR ──────────────────────────────────────────────────────────────────
const navItems = [
  { section: "Overview" },
  { id: "dashboard", label: "AI Dashboard", icon: "🤖" },
  { id: "analytics", label: "Analytics", icon: "📊" },
  { section: "Workspace" },
  { id: "crm", label: "CRM / Leads", icon: "👥" },
  { id: "finance", label: "Finance", icon: "💰" },
  { id: "projects", label: "Projects", icon: "🗂️" },
  { id: "kanban", label: "Kanban", icon: "📋" },
  { id: "calendar", label: "Calendar", icon: "📅" },
  { section: "Communication" },
  { id: "chat", label: "AI Chat", icon: "💬", badge: "AI" },
  { id: "email", label: "Email", icon: "📧" },
  { section: "Account" },
  { id: "settings", label: "Settings", icon: "⚙️" },
];

function Sidebar({ active, onNav, collapsed, onToggle, mobileOpen, notifications }: any) {
  const unread = notifications.filter((n: any) => !n.read).length;
  return (
    <div className={`sidebar${collapsed?" collapsed":""}${mobileOpen?" mobile-open":""}`}>
      <div className="sidebar-brand">
        <div className="brand-icon">✦</div>
        {!collapsed && (
          <>
            <div className="brand-name">Quantix UI</div>
            <div className="brand-tag">BETA</div>
          </>
        )}
      </div>
      <div className="nav-section">
        {navItems.map((item, i) => {
          if ("section" in item) {
            return collapsed ? null : <div key={i} className="nav-label">{item.section}</div>;
          }
          return (
            <div key={item.id} className={`nav-item${active===item.id?" active":""}`} onClick={()=>onNav(item.id)} title={collapsed?item.label:undefined}>
              <span className="nav-icon">{item.icon}</span>
              {!collapsed && <span>{item.label}</span>}
              {!collapsed && item.id==="email" && unread>0 && <span className="nav-badge">{unread}</span>}
              {!collapsed && item.badge && <span className="nav-badge">{item.badge}</span>}
            </div>
          );
        })}
      </div>
      <div style={{padding:"12px 8px",borderTop:"1px solid var(--border)"}}>
        <div className="nav-item" onClick={onToggle} title={collapsed?"Expand":"Collapse"}>
          <span className="nav-icon">{collapsed?"→":"←"}</span>
          {!collapsed && <span>Collapse</span>}
        </div>
      </div>
    </div>
  );
}

// ─── HEADER ───────────────────────────────────────────────────────────────────
function Header({ onMenuToggle, page, darkMode, toggleDark, onLogout, onNav, notifications, setNotifications }: any) {
  const [showNotif, setShowNotif] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const unread = notifications.filter((n: any) => !n.read).length;
  const markRead = (id: number) => setNotifications((p: any[]) => p.map(n => n.id===id?{...n,read:true}:n));
  const markAllRead = () => setNotifications((p: any[]) => p.map(n => ({...n,read:true})));

  const pageTitles: Record<string,string> = {
    dashboard:"AI Dashboard",analytics:"Analytics",crm:"CRM / Leads",
    finance:"Finance",projects:"Projects",kanban:"Kanban Board",
    calendar:"Calendar",chat:"AI Chat",email:"Email",settings:"Settings",
  };

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotif(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setShowProfile(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <div className="header">
      <button className="h-btn" onClick={onMenuToggle} title="Toggle sidebar">☰</button>
      <div style={{fontWeight:700,fontSize:15,marginRight:8}}>{pageTitles[page]||"Dashboard"}</div>
      <div className="h-spacer" />
      <div className="h-search">
        <span className="h-search-icon">🔍</span>
        <input placeholder="Search anything…" />
      </div>
      <button className="h-btn" onClick={toggleDark} title="Toggle theme">{darkMode ? "☀️" : "🌙"}</button>
      <div className="relative" ref={notifRef}>
        <button className="h-btn" onClick={()=>{setShowNotif(p=>!p);setShowProfile(false);}}>
          🔔
          {unread > 0 && <span className="badge-count">{unread}</span>}
        </button>
        {showNotif && (
          <div className="dropdown" style={{width:320}}>
            <div className="dropdown-header" style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <div>
                <div className="dropdown-name">Notifications</div>
                <div className="dropdown-email">{unread} unread</div>
              </div>
              {unread > 0 && <button className="btn btn-ghost btn-sm" onClick={markAllRead}>Mark all read</button>}
            </div>
            {notifications.map((n: any) => (
              <div key={n.id} className={`notif-item${n.read?"":" unread"}`} onClick={()=>markRead(n.id)}>
                <span className="notif-icon">{n.icon}</span>
                <div>
                  <div className="notif-text">{n.text}</div>
                  <div className="notif-time">{n.time}</div>
                </div>
                {!n.read && <div style={{width:7,height:7,background:"var(--accent)",borderRadius:"50%",flexShrink:0,marginLeft:"auto",marginTop:4}}></div>}
              </div>
            ))}
            <div className="notif-footer">View all notifications</div>
          </div>
        )}
      </div>
      <div className="relative" ref={profileRef}>
        <div className="avatar" onClick={()=>{setShowProfile(p=>!p);setShowNotif(false);}}>AM</div>
        {showProfile && (
          <div className="dropdown">
            <div className="dropdown-header">
              <div className="dropdown-name">Alex Morgan</div>
              <div className="dropdown-email">admin@quantix.io</div>
            </div>
            <div className="dropdown-item" onClick={()=>{onNav("settings");setShowProfile(false);}}>⚙️ Profile Settings</div>
            <div className="dropdown-item" onClick={()=>{onNav("billing");setShowProfile(false);}}>💳 Billing</div>
            <hr className="dropdown-divider" />
            <div className="dropdown-item danger" onClick={onLogout}>🚪 Sign out</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── DASHBOARD PAGE ───────────────────────────────────────────────────────────
function DashboardPage() {
  const [showNewReport, setShowNewReport] = useState(false);
  const [showAllActivity, setShowAllActivity] = useState(false);
  const [reportForm, setReportForm] = useState({ name:"", type:"Revenue", range:"Last 30 days", format:"PDF" });
  const [reportSaved, setReportSaved] = useState(false);

  const kpis = [
    { label:"Total Revenue", value:"$284K", change:"+18.2%", up:true, icon:"💰", cls:"kpi-accent" },
    { label:"Active Users", value:"42,891", change:"+11.7%", up:true, icon:"👥", cls:"kpi-green" },
    { label:"AI Queries / Day", value:"18,240", change:"+34.1%", up:true, icon:"🤖", cls:"kpi-cyan" },
    { label:"Churn Rate", value:"2.8%", change:"-1.4%", up:true, icon:"📉", cls:"kpi-orange" },
  ];

  const allActivity = [
    { action:"New enterprise lead", user:"Sarah Chen", time:"2 min ago", status:"Lead" },
    { action:"Payment received", user:"Meridian Labs", time:"18 min ago", status:"Payment" },
    { action:"AI model deployed", user:"System", time:"1h ago", status:"Deploy" },
    { action:"Support ticket closed", user:"Marcus R.", time:"2h ago", status:"Support" },
    { action:"New user registered", user:"Priya Nair", time:"3h ago", status:"User" },
    { action:"Invoice paid", user:"Cobalt Tech", time:"4h ago", status:"Payment" },
    { action:"API key generated", user:"Dev Team", time:"5h ago", status:"Deploy" },
    { action:"Report exported", user:"Alex Morgan", time:"6h ago", status:"Report" },
  ];

  const activity = showAllActivity ? allActivity : allActivity.slice(0, 5);

  const submitReport = () => {
    if (!reportForm.name) return;
    setReportSaved(true);
    setTimeout(() => { setReportSaved(false); setShowNewReport(false); setReportForm({ name:"", type:"Revenue", range:"Last 30 days", format:"PDF" }); }, 1400);
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">AI Dashboard</div><div className="page-sub">Welcome back, Alex 👋 Here&apos;s what&apos;s happening today.</div></div>
        <button className="btn btn-primary" onClick={()=>setShowNewReport(true)}>+ New Report</button>
      </div>
      <div className="grid-4 section-gap">
        {kpis.map(k => (
          <div key={k.label} className={`kpi ${k.cls}`}>
            <div className="kpi-icon">{k.icon}</div>
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value">{k.value}</div>
            <div className={`kpi-change ${k.up?"up":"down"}`}>{k.up?"▲":"▼"} {k.change} vs last month</div>
          </div>
        ))}
      </div>
      <div className="grid-2 section-gap">
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <div className="card-title">AI Usage Trend</div>
            <span className="badge badge-qualified">Live</span>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={aiUsageData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="week" tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} />
              <YAxis tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={fmtNum} />
              <Tooltip contentStyle={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:8,fontSize:12}} />
              <Line type="monotone" dataKey="queries" stroke="var(--accent)" strokeWidth={2} dot={false} />
              <Line type="monotone" dataKey="tokens" stroke="var(--accent2)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="card-title mb-3">Plan Distribution</div>
          <div style={{display:"flex",alignItems:"center",gap:20}}>
            <ResponsiveContainer width={160} height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={70} dataKey="value" paddingAngle={3}>
                  {pieData.map((e,i) => <Cell key={i} fill={e.color} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div style={{flex:1}}>
              {pieData.map(d => (
                <div key={d.name} style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
                  <div style={{width:10,height:10,borderRadius:2,background:d.color,flexShrink:0}}></div>
                  <span style={{fontSize:12,flex:1}}>{d.name}</span>
                  <span style={{fontSize:12,fontWeight:700}}>{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="card">
        <div className="flex items-center justify-between mb-3">
          <div className="card-title">Recent Activity</div>
          <button className="btn btn-ghost btn-sm" onClick={()=>setShowAllActivity(v=>!v)}>
            {showAllActivity ? "Show less ↑" : "View all ↓"}
          </button>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Action</th><th>User / Source</th><th>Time</th><th>Type</th></tr></thead>
            <tbody>{activity.map((a,i) => (
              <tr key={i}>
                <td style={{fontWeight:500}}>{a.action}</td>
                <td className="text-muted">{a.user}</td>
                <td className="text-dim text-sm">{a.time}</td>
                <td><span className="badge badge-medium">{a.status}</span></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      </div>

      {showNewReport && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowNewReport(false)}>
          <div className="modal">
            <div className="modal-header">
              <div className="modal-title">📊 Create New Report</div>
              <button className="btn btn-ghost btn-icon" onClick={()=>setShowNewReport(false)}>✕</button>
            </div>
            <div className="modal-body">
              {reportSaved ? (
                <div style={{textAlign:"center",padding:"24px 0"}}>
                  <div style={{fontSize:36,marginBottom:10}}>✅</div>
                  <div style={{fontWeight:700,fontSize:15}}>Report created!</div>
                  <div style={{color:"var(--text3)",fontSize:13,marginTop:4}}>&quot;{reportForm.name}&quot; has been queued.</div>
                </div>
              ) : (
                <>
                  <div className="form-group">
                    <label className="form-label">Report Name *</label>
                    <input className="form-input" placeholder="e.g. Q3 Revenue Summary" value={reportForm.name} onChange={e=>setReportForm(p=>({...p,name:e.target.value}))} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Report Type</label>
                    <select className="form-input form-select" value={reportForm.type} onChange={e=>setReportForm(p=>({...p,type:e.target.value}))}>
                      {["Revenue","User Growth","AI Usage","Traffic","Churn Analysis","Invoice Summary"].map(t=><option key={t}>{t}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Date Range</label>
                    <select className="form-input form-select" value={reportForm.range} onChange={e=>setReportForm(p=>({...p,range:e.target.value}))}>
                      {["Last 7 days","Last 30 days","Last 90 days","This year","Custom"].map(r=><option key={r}>{r}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Export Format</label>
                    <div className="flex gap-2">
                      {["PDF","CSV","Excel"].map(f=>(
                        <div key={f} onClick={()=>setReportForm(p=>({...p,format:f}))}
                          style={{flex:1,padding:"8px",textAlign:"center",borderRadius:8,border:`2px solid ${reportForm.format===f?"var(--accent)":"var(--border)"}`,cursor:"pointer",fontSize:13,fontWeight:600,background:reportForm.format===f?"var(--glow)":"var(--bg3)",color:reportForm.format===f?"var(--accent)":"var(--text2)"}}>
                          {f==="PDF"?"📄":f==="CSV"?"📋":"📊"} {f}
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
            {!reportSaved && (
              <div className="modal-footer">
                <button className="btn btn-secondary" onClick={()=>setShowNewReport(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={submitReport} disabled={!reportForm.name}>Generate Report</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── ANALYTICS PAGE ───────────────────────────────────────────────────────────
function AnalyticsPage() {
  const [period, setPeriod] = useState("7d");
  const [showExportMenu, setShowExportMenu] = useState(false);
  const exportRef = useRef<HTMLDivElement>(null);
  const dataMap: Record<string,typeof revenueData> = { "7d": revenueData.slice(-3), "30d": revenueData.slice(-5), "90d": revenueData };

  useEffect(() => {
    const handler = (e: MouseEvent) => { if (exportRef.current && !exportRef.current.contains(e.target as Node)) setShowExportMenu(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const exportCSV = (type: string) => {
    let rows: (string|number)[][], filename: string;
    if (type === "revenue") {
      rows = [["Month","Revenue","Expenses","Profit"],...revenueData.map(r=>[r.month,r.revenue,r.expenses,r.revenue-r.expenses])];
      filename = "analytics-revenue.csv";
    } else {
      rows = [["Day","Organic","Paid","Direct"],...trafficData.map(r=>[r.day,r.organic,r.paid,r.direct])];
      filename = "analytics-traffic.csv";
    }
    const csv = rows.map(r=>r.join(",")).join("\n");
    const a = document.createElement("a"); a.href = "data:text/csv;charset=utf-8,"+encodeURIComponent(csv); a.download = filename; a.click();
    setShowExportMenu(false);
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Analytics</div><div className="page-sub">Performance insights and traffic overview</div></div>
        <div className="relative" ref={exportRef}>
          <button className="btn btn-secondary" onClick={()=>setShowExportMenu(v=>!v)}>⬇️ Export ▾</button>
          {showExportMenu && (
            <div className="dropdown" style={{right:0,minWidth:180}}>
              <div className="dropdown-item" onClick={()=>exportCSV("revenue")}>📊 Revenue Data (CSV)</div>
              <div className="dropdown-item" onClick={()=>exportCSV("traffic")}>📈 Traffic Data (CSV)</div>
            </div>
          )}
        </div>
      </div>
      <div className="grid-4 section-gap">
        {[
          {label:"Total Revenue",value:"$1.24M",change:"+22%",up:true},
          {label:"Avg Session",value:"4m 32s",change:"+8%",up:true},
          {label:"Bounce Rate",value:"38.2%",change:"-4%",up:true},
          {label:"Conversion",value:"3.7%",change:"+0.9%",up:true},
        ].map(k => (
          <div key={k.label} className="kpi kpi-accent">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value" style={{fontSize:22}}>{k.value}</div>
            <div className={`kpi-change ${k.up?"up":"down"}`}>{k.up?"▲":"▼"} {k.change}</div>
          </div>
        ))}
      </div>
      <div className="card section-gap">
        <div className="flex items-center justify-between mb-3">
          <div className="card-title">Revenue Overview</div>
          <div className="toggle-group">
            {["7d","30d","90d"].map(p => (
              <div key={p} className={`toggle-btn${period===p?" active":""}`} onClick={()=>setPeriod(p)}>{p}</div>
            ))}
          </div>
        </div>
        <ResponsiveContainer width="100%" height={260}>
          <AreaChart data={dataMap[period]}>
            <defs>
              <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="var(--accent)" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="exp" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent2)" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="var(--accent2)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="month" tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} />
            <YAxis tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>`$${v/1000}K`} />
            <Tooltip contentStyle={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:8,fontSize:12}} formatter={(v:number)=>`$${v.toLocaleString()}`} />
            <Area type="monotone" dataKey="revenue" stroke="var(--accent)" fill="url(#rev)" strokeWidth={2} />
            <Area type="monotone" dataKey="expenses" stroke="var(--accent2)" fill="url(#exp)" strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      <div className="card section-gap">
        <div className="card-title mb-3">Traffic Sources</div>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={trafficData} barSize={12}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="day" tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} />
            <YAxis tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={fmtNum} />
            <Tooltip contentStyle={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:8,fontSize:12}} />
            <Legend wrapperStyle={{fontSize:12}} />
            <Bar dataKey="organic" fill="var(--accent)" radius={[4,4,0,0]} />
            <Bar dataKey="paid" fill="var(--accent2)" radius={[4,4,0,0]} />
            <Bar dataKey="direct" fill="var(--accent3)" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─── CRM PAGE ─────────────────────────────────────────────────────────────────
function CRMPage({ toast }: { toast: (msg: string, type?: string) => void }) {
  const [leads, setLeads] = useState(initialLeads);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ name:"", company:"", email:"", value:"", status:"Hot" });
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState("");
  const PER = 4;

  const filtered = leads.filter(l =>
    l.name.toLowerCase().includes(search.toLowerCase()) ||
    l.company.toLowerCase().includes(search.toLowerCase()) ||
    l.email.toLowerCase().includes(search.toLowerCase())
  );
  const pages = Math.ceil(filtered.length / PER);
  const paged = filtered.slice((page-1)*PER, page*PER);

  const validate = () => {
    const e: Record<string,string> = {};
    if (!form.name) e.name="Name required";
    if (!form.company) e.company="Company required";
    if (!form.email||!/\S+@\S+\.\S+/.test(form.email)) e.email="Valid email required";
    if (!form.value||isNaN(+form.value)||+form.value<=0) e.value="Enter a valid amount";
    return e;
  };

  const addLead = () => {
    const e = validate(); setErrors(e);
    if (Object.keys(e).length) return;
    setLeads(p => [...p, { id:Date.now(), name:form.name, company:form.company, email:form.email, status:form.status, value:+form.value, date:new Date().toISOString().slice(0,10) }]);
    setShowModal(false); setForm({ name:"", company:"", email:"", value:"", status:"Hot" }); setErrors({});
    toast("Lead added!");
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">CRM / Leads</div><div className="page-sub">{leads.length} total leads</div></div>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>+ Add Lead</button>
      </div>
      <div className="card">
        <div className="flex items-center gap-3 mb-3">
          <input className="form-input" style={{maxWidth:280,marginBottom:0}} placeholder="Search leads…" value={search} onChange={e=>{setSearch(e.target.value);setPage(1);}} />
          <span className="text-sm text-muted">{filtered.length} results</span>
        </div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Name</th><th>Company</th><th>Status</th><th>Value</th><th>Date</th><th></th></tr></thead>
            <tbody>{paged.map(l => (
              <tr key={l.id}>
                <td><div style={{fontWeight:600}}>{l.name}</div><div style={{fontSize:11,color:"var(--text3)"}}>{l.email}</div></td>
                <td>{l.company}</td>
                <td><span className={`badge badge-${l.status.toLowerCase()}`}>{l.status}</span></td>
                <td style={{fontWeight:600}}>{fmt(l.value)}</td>
                <td className="text-sm text-muted">{l.date}</td>
                <td><button className="btn btn-danger btn-xs" onClick={()=>{setLeads(p=>p.filter(x=>x.id!==l.id));toast("Lead deleted");}}>✕</button></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        {pages > 1 && (
          <div className="flex items-center justify-between mt-3" style={{paddingTop:12,borderTop:"1px solid var(--border)"}}>
            <span className="text-sm text-muted">Page {page} of {pages}</span>
            <div className="flex gap-2">
              <button className="btn btn-secondary btn-sm" disabled={page===1} onClick={()=>setPage(p=>p-1)}>← Prev</button>
              <button className="btn btn-secondary btn-sm" disabled={page===pages} onClick={()=>setPage(p=>p+1)}>Next →</button>
            </div>
          </div>
        )}
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">Add New Lead</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowModal(false)}>✕</button></div>
            <div className="modal-body">
              {([["name","Full Name","text","Alex Morgan"],["company","Company","text","Acme Corp"],["email","Email","email","alex@acme.com"],["value","Deal Value","number","25000"]] as [string,string,string,string][]).map(([f,l,t,ph])=>(
                <div className="form-group" key={f}>
                  <label className="form-label">{l}</label>
                  <input className="form-input" type={t} placeholder={ph} value={(form as any)[f]} onChange={e=>setForm(p=>({...p,[f]:e.target.value}))} />
                  {errors[f] && <div className="form-error">{errors[f]}</div>}
                </div>
              ))}
              <div className="form-group">
                <label className="form-label">Status</label>
                <select className="form-input form-select" value={form.status} onChange={e=>setForm(p=>({...p,status:e.target.value}))}>
                  {["Hot","Warm","Cold","Qualified"].map(s=><option key={s}>{s}</option>)}
                </select>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={addLead}>Add Lead</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── FINANCE PAGE ─────────────────────────────────────────────────────────────
function FinancePage({ toast }: { toast: (msg: string, type?: string) => void }) {
  const [invoices, setInvoices] = useState([
    {id:"INV-001",client:"Vertex Corp",amount:12400,status:"Paid",date:"Jul 15"},
    {id:"INV-002",client:"Meridian Labs",amount:8750,status:"Pending",date:"Jul 18"},
    {id:"INV-003",client:"Solaris AI",amount:5200,status:"Paid",date:"Jul 20"},
    {id:"INV-004",client:"Cobalt Tech",amount:19800,status:"Overdue",date:"Jul 05"},
    {id:"INV-005",client:"Neon Digital",amount:6300,status:"Draft",date:"Jul 22"},
  ]);
  const [page, setPage] = useState(1);
  const [showModal, setShowModal] = useState(false);
  const [invForm, setInvForm] = useState({ client:"", amount:"", status:"Draft", date:"" });
  const [invErrors, setInvErrors] = useState<Record<string,string>>({});
  const PER = 3;

  const validateInv = () => {
    const e: Record<string,string> = {};
    if (!invForm.client) e.client = "Client name required";
    if (!invForm.amount || isNaN(+invForm.amount) || +invForm.amount <= 0) e.amount = "Enter a valid amount";
    return e;
  };

  const addInvoice = () => {
    const e = validateInv(); setInvErrors(e);
    if (Object.keys(e).length) return;
    const nextNum = String(invoices.length + 1).padStart(3,"0");
    const today = new Date();
    const dateStr = invForm.date
      ? new Date(invForm.date).toLocaleDateString("en-US",{month:"short",day:"numeric"})
      : today.toLocaleDateString("en-US",{month:"short",day:"numeric"});
    setInvoices(p => [...p, { id:`INV-${nextNum}`, client:invForm.client, amount:+invForm.amount, status:invForm.status, date:dateStr }]);
    setShowModal(false); setInvForm({ client:"", amount:"", status:"Draft", date:"" }); setInvErrors({});
    toast("Invoice created!");
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Finance</div><div className="page-sub">Revenue & invoice management</div></div>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>+ New Invoice</button>
      </div>
      <div className="grid-4 section-gap">
        {[
          {label:"MRR",value:"$68,400",change:"+12%",up:true},
          {label:"ARR",value:"$820,800",change:"+18%",up:true},
          {label:"Outstanding",value:"$28,550",change:"+5%",up:false},
          {label:"Expenses",value:"$41,200",change:"-3%",up:true},
        ].map(k=>(
          <div key={k.label} className="kpi kpi-accent">
            <div className="kpi-label">{k.label}</div>
            <div className="kpi-value" style={{fontSize:22}}>{k.value}</div>
            <div className={`kpi-change ${k.up?"up":"down"}`}>{k.up?"▲":"▼"} {k.change}</div>
          </div>
        ))}
      </div>
      <div className="grid-2 section-gap">
        <div className="card">
          <div className="card-title mb-3">Monthly Revenue vs Expenses</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={revenueData} barSize={12}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} />
              <YAxis tick={{fill:"var(--text3)",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>`$${v/1000}K`} />
              <Tooltip contentStyle={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:8,fontSize:12}} formatter={(v:number)=>`$${v.toLocaleString()}`} />
              <Bar dataKey="revenue" fill="var(--accent)" radius={[4,4,0,0]} />
              <Bar dataKey="expenses" fill="var(--bg4)" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="card">
          <div className="card-title mb-3">Invoice Status</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={[{name:"Paid",value:3,color:"var(--green)"},{name:"Pending",value:1,color:"var(--orange)"},{name:"Overdue",value:1,color:"var(--red)"}]} cx="50%" cy="50%" outerRadius={80} dataKey="value">
                {["var(--green)","var(--orange)","var(--red)"].map((c,i)=><Cell key={i} fill={c}/>)}
              </Pie>
              <Tooltip contentStyle={{background:"var(--bg2)",border:"1px solid var(--border2)",borderRadius:8,fontSize:12}} />
              <Legend wrapperStyle={{fontSize:12}} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="card">
        <div className="card-title mb-3">Invoices</div>
        <div className="table-wrap">
          <table>
            <thead><tr><th>Invoice</th><th>Client</th><th>Amount</th><th>Status</th><th>Date</th><th></th></tr></thead>
            <tbody>{invoices.slice((page-1)*PER,page*PER).map(inv=>(
              <tr key={inv.id}>
                <td style={{fontFamily:"var(--mono)",fontSize:12}}>{inv.id}</td>
                <td style={{fontWeight:500}}>{inv.client}</td>
                <td style={{fontWeight:700}}>{fmt(inv.amount)}</td>
                <td><span className={`badge ${inv.status==="Paid"?"badge-qualified":inv.status==="Pending"?"badge-warm":inv.status==="Overdue"?"badge-hot":"badge-medium"}`}>{inv.status}</span></td>
                <td className="text-sm text-muted">{inv.date}</td>
                <td><button className="btn btn-ghost btn-xs">View</button></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        <div className="flex items-center justify-between mt-3" style={{paddingTop:12,borderTop:"1px solid var(--border)"}}>
          <span className="text-sm text-muted">Showing {Math.min((page-1)*PER+1,invoices.length)}–{Math.min(page*PER,invoices.length)} of {invoices.length}</span>
          <div className="flex gap-2">
            <button className="btn btn-secondary btn-sm" disabled={page===1} onClick={()=>setPage(p=>p-1)}>←</button>
            <button className="btn btn-secondary btn-sm" disabled={page*PER>=invoices.length} onClick={()=>setPage(p=>p+1)}>→</button>
          </div>
        </div>
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">🧾 New Invoice</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowModal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Client Name *</label><input className="form-input" placeholder="Acme Corp" value={invForm.client} onChange={e=>setInvForm(p=>({...p,client:e.target.value}))} />{invErrors.client&&<div className="form-error">{invErrors.client}</div>}</div>
              <div className="form-group"><label className="form-label">Amount (USD) *</label><input className="form-input" type="number" placeholder="5000" value={invForm.amount} onChange={e=>setInvForm(p=>({...p,amount:e.target.value}))} />{invErrors.amount&&<div className="form-error">{invErrors.amount}</div>}</div>
              <div className="form-group"><label className="form-label">Status</label><select className="form-input form-select" value={invForm.status} onChange={e=>setInvForm(p=>({...p,status:e.target.value}))}>{["Draft","Pending","Paid","Overdue"].map(s=><option key={s}>{s}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Invoice Date</label><input className="form-input" type="date" value={invForm.date} onChange={e=>setInvForm(p=>({...p,date:e.target.value}))} /></div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setShowModal(false)}>Cancel</button><button className="btn btn-primary" onClick={addInvoice}>Create Invoice</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── PROJECTS PAGE ────────────────────────────────────────────────────────────
function ProjectsPage({ toast }: { toast: (msg: string, type?: string) => void }) {
  const [projects, setProjects] = useState(initialProjects);
  const [showModal, setShowModal] = useState(false);
  const [detail, setDetail] = useState<any>(null);
  const [form, setForm] = useState({ name:"", priority:"Medium", due:"", team:"" });
  const [formError, setFormError] = useState("");

  const addProject = () => {
    if (!form.name.trim()) { setFormError("Project name is required"); return; }
    setFormError("");
    const teamArr = form.team.trim() ? form.team.split(",").map((t: string)=>t.trim().slice(0,2).toUpperCase()).filter(Boolean) : ["NA"];
    const dueLabel = form.due ? new Date(form.due).toLocaleDateString("en-US",{month:"short",day:"numeric"}) : "TBD";
    setProjects(prev => [...prev, { id:Date.now(), name:form.name.trim(), status:"Planning", progress:0, team:teamArr, due:dueLabel, priority:form.priority }]);
    setShowModal(false); setForm({ name:"", priority:"Medium", due:"", team:"" });
    toast("Project created!");
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Projects</div><div className="page-sub">{projects.length} active projects</div></div>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>+ New Project</button>
      </div>
      <div className="grid-2">
        {projects.map(p => (
          <div key={p.id} className="card" style={{cursor:"pointer"}} onClick={()=>setDetail(p)}>
            <div className="flex items-center justify-between mb-2">
              <div style={{fontWeight:700,fontSize:15}}>{p.name}</div>
              <span className={`badge badge-${p.priority.toLowerCase()}`}>{p.priority}</span>
            </div>
            <div className="flex items-center gap-2 mb-3">
              <span className={`badge badge-${p.status.toLowerCase().replace(" ","-")}`}>{p.status}</span>
              <span className="text-sm text-muted">Due: {p.due}</span>
            </div>
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm text-muted">Progress</span>
              <span style={{fontSize:13,fontWeight:700}}>{p.progress}%</span>
            </div>
            <div className="progress-bar"><div className="progress-fill" style={{width:`${p.progress}%`}}></div></div>
            <div className="flex gap-1 mt-3">
              {p.team.map((m: string) => (
                <div key={m} style={{width:26,height:26,borderRadius:"50%",background:"var(--accent)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:"white",border:"2px solid var(--bg2)"}}>{m}</div>
              ))}
            </div>
          </div>
        ))}
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">🗂️ New Project</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowModal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Project Name *</label><input className="form-input" placeholder="Platform v3 Launch" value={form.name} onChange={e=>setForm(p=>({...p,name:e.target.value}))} />{formError&&<div className="form-error">{formError}</div>}</div>
              <div className="form-group"><label className="form-label">Priority</label><select className="form-input form-select" value={form.priority} onChange={e=>setForm(p=>({...p,priority:e.target.value}))}>{["Low","Medium","High","Critical"].map(v=><option key={v}>{v}</option>)}</select></div>
              <div className="form-group"><label className="form-label">Due Date</label><input className="form-input" type="date" value={form.due} onChange={e=>setForm(p=>({...p,due:e.target.value}))} /></div>
              <div className="form-group"><label className="form-label">Team Members <span style={{color:"var(--text3)",fontWeight:400}}>(comma-separated initials)</span></label><input className="form-input" placeholder="AK, SR, MJ" value={form.team} onChange={e=>setForm(p=>({...p,team:e.target.value}))} /></div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setShowModal(false)}>Cancel</button><button className="btn btn-primary" onClick={addProject}>Create Project</button></div>
          </div>
        </div>
      )}
      {detail && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setDetail(null)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">{detail.name}</div><button className="btn btn-ghost btn-icon" onClick={()=>setDetail(null)}>✕</button></div>
            <div className="modal-body">
              <div className="flex gap-2 mb-3">
                <span className={`badge badge-${detail.status.toLowerCase().replace(" ","-")}`}>{detail.status}</span>
                <span className={`badge badge-${detail.priority.toLowerCase()}`}>{detail.priority}</span>
              </div>
              <div className="flex items-center justify-between mb-1"><span className="text-sm text-muted">Progress</span><span style={{fontWeight:700}}>{detail.progress}%</span></div>
              <div className="progress-bar mb-3"><div className="progress-fill" style={{width:`${detail.progress}%`}}></div></div>
              <div className="form-group"><span className="form-label">Due Date</span><div style={{fontSize:13,marginTop:2}}>{detail.due}</div></div>
              <div className="form-group"><span className="form-label">Team</span><div className="flex gap-1 mt-1">{detail.team.map((m: string)=><div key={m} style={{width:28,height:28,borderRadius:"50%",background:"var(--accent)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:"white"}}>{m}</div>)}</div></div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setDetail(null)}>Close</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── KANBAN PAGE ──────────────────────────────────────────────────────────────
function KanbanPage() {
  const [board, setBoard] = useState(initialKanban);
  const [showModal, setShowModal] = useState(false);
  const [taskForm, setTaskForm] = useState({ title:"", column:"todo", tag:"Dev", priority:"Medium" });
  const [taskError, setTaskError] = useState("");
  const [dragging, setDragging] = useState<{id:string;from:string}|null>(null);

  const cols = [
    {id:"todo",label:"To Do",color:"var(--text3)"},
    {id:"inprogress",label:"In Progress",color:"var(--accent)"},
    {id:"review",label:"Review",color:"var(--orange)"},
    {id:"done",label:"Done",color:"var(--green)"},
  ];

  const addTask = () => {
    if (!taskForm.title.trim()) { setTaskError("Task title is required"); return; }
    setTaskError("");
    const newTask = { id:`t${uid()}`, title:taskForm.title.trim(), tag:taskForm.tag, priority:taskForm.priority };
    setBoard(p => ({...p, [taskForm.column]:[...p[taskForm.column as keyof typeof p], newTask]}));
    setShowModal(false); setTaskForm({ title:"", column:"todo", tag:"Dev", priority:"Medium" });
  };

  const moveCard = (id: string, fromCol: string, toCol: string) => {
    if (fromCol === toCol) return;
    setBoard(p => {
      const card = (p[fromCol as keyof typeof p] as any[]).find((c: any) => c.id === id);
      if (!card) return p;
      return {
        ...p,
        [fromCol]: (p[fromCol as keyof typeof p] as any[]).filter((c: any) => c.id !== id),
        [toCol]: [...(p[toCol as keyof typeof p] as any[]), card],
      };
    });
  };

  const removeCard = (id: string, col: string) => {
    setBoard(p => ({...p, [col]:(p[col as keyof typeof p] as any[]).filter((c: any)=>c.id!==id)}));
  };

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Kanban Board</div><div className="page-sub">Drag cards to move between columns</div></div>
        <button className="btn btn-primary" onClick={()=>setShowModal(true)}>+ Add Task</button>
      </div>
      <div className="kanban-board">
        {cols.map(col => {
          const cards = board[col.id as keyof typeof board] as any[];
          return (
            <div key={col.id} className="kanban-col"
              onDragOver={e=>e.preventDefault()}
              onDrop={e=>{e.preventDefault();if(dragging&&dragging.from!==col.id){moveCard(dragging.id,dragging.from,col.id);setDragging(null);}}}>
              <div className="kanban-col-header">
                <span style={{color:col.color}}>{col.label}</span>
                <span style={{fontSize:12,fontWeight:600,background:"var(--bg4)",padding:"2px 8px",borderRadius:99}}>{cards.length}</span>
              </div>
              <div className="kanban-cards">
                {cards.map((card: any) => (
                  <div key={card.id} className={`kanban-card${dragging?.id===card.id?" dragging":""}`}
                    draggable onDragStart={()=>setDragging({id:card.id,from:col.id})} onDragEnd={()=>setDragging(null)}>
                    <div className="kanban-card-title">{card.title}</div>
                    <div className="flex items-center justify-between">
                      <span style={{fontSize:10,background:"var(--bg4)",padding:"2px 6px",borderRadius:4,fontWeight:600,color:"var(--text3)"}}>{card.tag}</span>
                      <span className={`badge badge-${card.priority.toLowerCase()}`} style={{fontSize:10}}>{card.priority}</span>
                    </div>
                    <div className="flex gap-1 mt-2">
                      {cols.filter(c=>c.id!==col.id).map(c=>(
                        <button key={c.id} className="btn btn-ghost btn-xs" style={{fontSize:10,padding:"2px 6px"}} onClick={()=>moveCard(card.id,col.id,c.id)} title={`Move to ${c.label}`}>→{c.label.split(" ")[0]}</button>
                      ))}
                      <button className="btn btn-danger btn-xs" style={{fontSize:10,padding:"2px 6px",marginLeft:"auto"}} onClick={()=>removeCard(card.id,col.id)}>✕</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">Add Task</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowModal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Task Title *</label><input className="form-input" placeholder="Implement auth flow" value={taskForm.title} onChange={e=>setTaskForm(p=>({...p,title:e.target.value}))} autoFocus />{taskError&&<div className="form-error">{taskError}</div>}</div>
              <div className="form-group"><label className="form-label">Column</label><select className="form-input form-select" value={taskForm.column} onChange={e=>setTaskForm(p=>({...p,column:e.target.value}))}>{cols.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}</select></div>
              <div className="grid-2">
                <div className="form-group"><label className="form-label">Tag</label><select className="form-input form-select" value={taskForm.tag} onChange={e=>setTaskForm(p=>({...p,tag:e.target.value}))}>{["Dev","Design","Research","Testing","DevOps","Docs","QA","Marketing"].map(t=><option key={t}>{t}</option>)}</select></div>
                <div className="form-group"><label className="form-label">Priority</label><select className="form-input form-select" value={taskForm.priority} onChange={e=>setTaskForm(p=>({...p,priority:e.target.value}))}>{["Low","Medium","High","Critical"].map(v=><option key={v}>{v}</option>)}</select></div>
              </div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setShowModal(false)}>Cancel</button><button className="btn btn-primary" onClick={addTask}>Add Task</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CALENDAR PAGE ────────────────────────────────────────────────────────────
function CalendarPage({ toast }: { toast: (msg: string) => void }) {
  const today = new Date();
  const [cur, setCur] = useState({ year: today.getFullYear(), month: today.getMonth() });
  const [events, setEvents] = useState([
    { id:1, date:"2024-07-15", title:"Product sync", color:"var(--accent)" },
    { id:2, date:"2024-07-18", title:"Investor call", color:"var(--green)" },
    { id:3, date:"2024-07-22", title:"Sprint review", color:"var(--orange)" },
  ]);
  const [showModal, setShowModal] = useState(false);
  const [selDate, setSelDate] = useState("");
  const [newTitle, setNewTitle] = useState("");

  const daysInMonth = new Date(cur.year, cur.month+1, 0).getDate();
  const firstDay = new Date(cur.year, cur.month, 1).getDay();
  const prevDays = new Date(cur.year, cur.month, 0).getDate();
  const months = ["January","February","March","April","May","June","July","August","September","October","November","December"];

  const addEvent = () => {
    if (!newTitle || !selDate) return;
    setEvents(p => [...p, { id: Date.now(), date: selDate, title: newTitle, color: "var(--accent)" }]);
    setShowModal(false); setNewTitle(""); toast("Event added!");
  };

  const cells: {day:number;type:string}[] = [];
  for (let i = firstDay - 1; i >= 0; i--) cells.push({ day: prevDays - i, type: "prev" });
  for (let i = 1; i <= daysInMonth; i++) cells.push({ day: i, type: "cur" });
  const rem = 42 - cells.length;
  for (let i = 1; i <= rem; i++) cells.push({ day: i, type: "next" });

  const fmtDate = (d: number) => `${cur.year}-${String(cur.month+1).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
  const todayStr = `${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;

  return (
    <div>
      <div className="page-header">
        <div><div className="page-title">Calendar</div><div className="page-sub">Schedule and event management</div></div>
        <button className="btn btn-primary" onClick={()=>{setSelDate(todayStr);setShowModal(true);}}>+ Add Event</button>
      </div>
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <div style={{fontSize:18,fontWeight:800}}>{months[cur.month]} {cur.year}</div>
          <div className="flex gap-2">
            <button className="btn btn-secondary btn-sm" onClick={()=>setCur(p=>p.month===0?{year:p.year-1,month:11}:{...p,month:p.month-1})}>←</button>
            <button className="btn btn-secondary btn-sm" onClick={()=>setCur({year:today.getFullYear(),month:today.getMonth()})}>Today</button>
            <button className="btn btn-secondary btn-sm" onClick={()=>setCur(p=>p.month===11?{year:p.year+1,month:0}:{...p,month:p.month+1})}>→</button>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:4,marginBottom:8}}>
          {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map(d=><div key={d} style={{textAlign:"center",fontSize:11,fontWeight:700,color:"var(--text3)",padding:"4px 0"}}>{d}</div>)}
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:4}}>
          {cells.map((c, i) => {
            const ds = c.type==="cur" ? fmtDate(c.day) : "";
            const dayEvents = events.filter(e => e.date === ds);
            const isToday = ds === todayStr;
            return (
              <div key={i}
                style={{minHeight:70,background:isToday?"var(--glow)":c.type!=="cur"?"transparent":"var(--bg3)",border:`1px solid ${isToday?"var(--accent)":"var(--border)"}`,borderRadius:8,padding:"6px 8px",cursor:c.type==="cur"?"pointer":"default",opacity:c.type!=="cur"?0.3:1}}
                onClick={()=>{if(c.type==="cur"){setSelDate(ds);setShowModal(true);}}}>
                <div style={{fontSize:12,fontWeight:isToday?800:500,color:isToday?"var(--accent)":"var(--text)"}}>{c.day}</div>
                {dayEvents.map(ev => (
                  <div key={ev.id}
                    style={{fontSize:10,background:ev.color,color:"white",borderRadius:3,padding:"2px 4px",marginTop:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",cursor:"pointer"}}
                    onClick={e=>{e.stopPropagation();if(window.confirm(`Delete "${ev.title}"?`)){setEvents(p=>p.filter(x=>x.id!==ev.id));toast("Event deleted");}}}
                    title={`Click to delete: ${ev.title}`}>{ev.title}</div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
      {showModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">Add Event</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowModal(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Date</label><input className="form-input" type="date" value={selDate} onChange={e=>setSelDate(e.target.value)} /></div>
              <div className="form-group"><label className="form-label">Event Title</label><input className="form-input" placeholder="Team standup" value={newTitle} onChange={e=>setNewTitle(e.target.value)} onKeyDown={e=>e.key==="Enter"&&addEvent()} /></div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setShowModal(false)}>Cancel</button><button className="btn btn-primary" onClick={addEvent}>Add Event</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── CHAT PAGE ────────────────────────────────────────────────────────────────
function ChatPage() {
  const [convs, setConvs] = useState(chatConversations);
  const [activeId, setActiveId] = useState("c1");
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const active = convs.find(c => c.id === activeId);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [active?.messages, typing]);

  const send = () => {
    if (!input.trim()) return;
    const msg = input.trim(); setInput("");
    setConvs(p => p.map(c => c.id===activeId ? {...c, messages:[...c.messages,{role:"user",content:msg}]} : c));
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setConvs(p => p.map(c => c.id===activeId ? {...c, messages:[...c.messages,{role:"ai",content:`I've analyzed your query: **"${msg}"**\n\nBased on the current dashboard data:\n\n1. **Trend analysis** shows positive momentum\n2. **Recommendation**: Focus on highest-impact opportunities\n3. **Action item**: Review the detailed breakdown in Analytics\n\nWould you like me to dive deeper into any specific area?`}]} : c));
    }, 1200 + Math.random()*800);
  };

  const newChat = () => {
    const id = "c" + uid();
    setConvs(p => [...p, { id, title: "New conversation", messages: [] }]);
    setActiveId(id);
  };

  const renderMsg = (text: string) => text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>');

  return (
    <div>
      <div className="page-header"><div className="page-title">AI Chat</div></div>
      <div className="card" style={{padding:0,overflow:"hidden"}}>
        <div className="chat-layout">
          <div className="chat-sidebar">
            <button className="btn btn-primary w-full mb-3" onClick={newChat} style={{justifyContent:"center"}}>+ New Chat</button>
            {convs.map(c => (
              <div key={c.id} className={`conv-item${activeId===c.id?" active":""}`} onClick={()=>setActiveId(c.id)}>
                💬 {c.title}
              </div>
            ))}
          </div>
          <div className="chat-main">
            <div style={{padding:"12px 16px",borderBottom:"1px solid var(--border)",fontWeight:700,fontSize:14}}>{active?.title}</div>
            <div className="chat-messages">
              {active?.messages.length === 0 && (
                <div style={{textAlign:"center",color:"var(--text3)",marginTop:40}}>
                  <div style={{fontSize:40,marginBottom:12}}>🤖</div>
                  <div style={{fontSize:14,fontWeight:600}}>How can I help you today?</div>
                  <div style={{fontSize:12,marginTop:4}}>Ask me anything about your data</div>
                </div>
              )}
              {active?.messages.map((m: any, i: number) => (
                <div key={i} className={`msg ${m.role}`}>
                  <div className="msg-bubble" dangerouslySetInnerHTML={{__html:renderMsg(m.content)}} />
                  <div className="msg-meta">{m.role === "user" ? "You" : "AI Assistant"}</div>
                </div>
              ))}
              {typing && (
                <div className="msg ai">
                  <div className="msg-bubble"><div className="typing-indicator"><div className="typing-dot"/><div className="typing-dot"/><div className="typing-dot"/></div></div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>
            <div className="chat-input-area">
              <div className="chat-input-row">
                <textarea className="chat-input" placeholder="Type a message… (Enter to send)" value={input}
                  onChange={e=>setInput(e.target.value)}
                  onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();send();}}}
                  rows={1} />
                <button className="btn btn-primary" onClick={send} disabled={!input.trim()||typing}>Send</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── EMAIL PAGE ───────────────────────────────────────────────────────────────
function EmailPage({ toast }: { toast: (msg: string) => void }) {
  const [emails, setEmails] = useState(initialEmails);
  const [folder, setFolder] = useState("inbox");
  const [selected, setSelected] = useState<any>(null);
  const [showCompose, setShowCompose] = useState(false);
  const [compose, setCompose] = useState({ to:"", subject:"", body:"" });
  const [composeErrors, setComposeErrors] = useState<Record<string,string>>({});

  const folders = [
    { id:"inbox", icon:"📥", label:"Inbox", count: emails.inbox.filter(e=>!e.read).length },
    { id:"starred", icon:"⭐", label:"Starred" },
    { id:"sent", icon:"📤", label:"Sent" },
    { id:"drafts", icon:"📝", label:"Drafts", count: emails.drafts.length },
    { id:"trash", icon:"🗑️", label:"Trash" },
  ];

  const getEmails = () => {
    if (folder === "starred") return [...emails.inbox,...emails.sent].filter(e=>e.starred);
    return (emails as any)[folder] || [];
  };

  const markRead = (id: string) => setEmails(p => ({...p, inbox: p.inbox.map(e=>e.id===id?{...e,read:true}:e)}));
  const toggleStar = (id: string) => {
    setEmails(p => {
      const upd = (arr: any[]) => arr.map(e => e.id===id?{...e,starred:!e.starred}:e);
      return {...p, inbox:upd(p.inbox), sent:upd(p.sent)};
    });
  };
  const deleteEmail = (email: any) => {
    setEmails(p => {
      const remove = (arr: any[]) => arr.filter(e=>e.id!==email.id);
      if (folder==="trash") return {...p, trash:remove(p.trash)};
      return {...p, [folder]:remove((p as any)[folder]), trash:[...p.trash,email]};
    });
    setSelected(null); toast("Moved to trash");
  };

  const validateCompose = () => {
    const e: Record<string,string> = {};
    if (!compose.to||!/\S+@\S+\.\S+/.test(compose.to)) e.to="Valid email required";
    if (!compose.subject) e.subject="Subject required";
    return e;
  };

  const sendEmail = () => {
    const e = validateCompose(); setComposeErrors(e);
    if (Object.keys(e).length) return;
    const newEmail = { id:`sent_${uid()}`, from:"Me", subject:compose.subject, preview:compose.body.slice(0,60)+"…", date:"Just now", read:true, starred:false };
    setEmails(p => ({...p, sent:[newEmail,...p.sent]}));
    setShowCompose(false); setCompose({ to:"", subject:"", body:"" });
    toast("Email sent!");
  };

  const saveDraft = () => {
    const draft = { id:`draft_${uid()}`, from:"Me", subject:compose.subject||"(no subject)", preview:compose.body.slice(0,60), date:"Now", read:true, starred:false };
    setEmails(p => ({...p, drafts:[draft,...p.drafts]}));
    setShowCompose(false); setCompose({ to:"", subject:"", body:"" });
    toast("Draft saved");
  };

  const curEmails = getEmails();

  return (
    <div>
      <div className="page-header"><div className="page-title">Email</div><button className="btn btn-primary" onClick={()=>setShowCompose(true)}>✏️ Compose</button></div>
      <div className="card" style={{padding:0,overflow:"hidden"}}>
        <div className="email-layout">
          <div className="email-sidebar">
            {folders.map(f => (
              <div key={f.id} className={`email-folder${folder===f.id?" active":""}`} onClick={()=>{setFolder(f.id);setSelected(null);}}>
                <span>{f.icon}</span>
                <span style={{flex:1}}>{f.label}</span>
                {(f as any).count > 0 && <span className="nav-badge">{(f as any).count}</span>}
              </div>
            ))}
          </div>
          <div className="email-list">
            <div style={{padding:"10px 14px",borderBottom:"1px solid var(--border)",fontSize:12,fontWeight:700,color:"var(--text3)",textTransform:"uppercase",letterSpacing:0.5}}>{folder} ({curEmails.length})</div>
            {curEmails.length === 0 && <div style={{padding:20,color:"var(--text3)",fontSize:13,textAlign:"center"}}>No messages</div>}
            {curEmails.map((e: any) => (
              <div key={e.id} className={`email-item${selected?.id===e.id?" active":""}${!e.read?" unread":""}`} onClick={()=>{setSelected(e);markRead(e.id);}}>
                <div className="flex items-center justify-between mb-1">
                  <div className="email-from">{e.from}</div>
                  <div className="email-date">{e.date}</div>
                </div>
                <div className="email-subject">{e.subject}</div>
                <div className="email-preview-text">{e.preview}</div>
              </div>
            ))}
          </div>
          <div className="email-view">
            {selected ? (
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div style={{fontWeight:700,fontSize:16}}>{selected.subject}</div>
                  <div className="flex gap-2">
                    <button className="btn btn-ghost btn-sm" onClick={()=>toggleStar(selected.id)}>{selected.starred?"⭐":"☆"} Star</button>
                    <button className="btn btn-ghost btn-sm" onClick={()=>deleteEmail(selected)}>🗑️ Delete</button>
                  </div>
                </div>
                <div style={{marginBottom:16}}>
                  <div style={{fontSize:13,color:"var(--text2)"}}>From: <strong>{selected.from}</strong></div>
                  <div style={{fontSize:12,color:"var(--text3)"}}>Date: {selected.date}</div>
                </div>
                <div style={{fontSize:13,lineHeight:1.7,color:"var(--text2)"}}>{selected.preview}</div>
                <div style={{marginTop:20}}>
                  <button className="btn btn-secondary btn-sm">↩ Reply</button>
                </div>
              </div>
            ) : (
              <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",color:"var(--text3)"}}>
                <div style={{fontSize:40,marginBottom:12}}>📧</div>
                <div style={{fontSize:14}}>Select an email to read</div>
              </div>
            )}
          </div>
        </div>
      </div>
      {showCompose && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowCompose(false)}>
          <div className="modal" style={{maxWidth:560}}>
            <div className="modal-header"><div className="modal-title">✏️ Compose Email</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowCompose(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">To</label><input className="form-input" placeholder="recipient@email.com" value={compose.to} onChange={e=>setCompose(p=>({...p,to:e.target.value}))} />{composeErrors.to&&<div className="form-error">{composeErrors.to}</div>}</div>
              <div className="form-group"><label className="form-label">Subject</label><input className="form-input" placeholder="Email subject" value={compose.subject} onChange={e=>setCompose(p=>({...p,subject:e.target.value}))} />{composeErrors.subject&&<div className="form-error">{composeErrors.subject}</div>}</div>
              <div className="form-group"><label className="form-label">Message</label><textarea className="form-input" rows={8} placeholder="Write your message…" value={compose.body} onChange={e=>setCompose(p=>({...p,body:e.target.value}))} /></div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={saveDraft}>Save Draft</button>
              <button className="btn btn-secondary" onClick={()=>setShowCompose(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={sendEmail}>Send ✉️</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── SETTINGS PAGE ────────────────────────────────────────────────────────────
function SettingsPage({ toast, initialTab = "profile" }: { toast: (msg: string, type?: string) => void; initialTab?: string }) {
  const [tab, setTab] = useState(initialTab);
  const [profile, setProfile] = useState({ name:"Alex Morgan", email:"admin@quantix.io", company:"Quantix Labs", role:"Super Admin" });
  const [errors, setErrors] = useState<Record<string,string>>({});
  const [avatarPreview, setAvatarPreview] = useState<string|null>(null);
  const [plan, setPlan] = useState("Pro");
  const [subStatus, setSubStatus] = useState("Active");
  const [showPlanModal, setShowPlanModal] = useState<string|null>(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [showAddCard, setShowAddCard] = useState(false);
  const [cards, setCards] = useState([{ id:1, last4:"4242", brand:"Visa", expiry:"12/26", name:"Alex Morgan", isDefault:true }]);
  const [newCard, setNewCard] = useState({ number:"", name:"", expiry:"", cvc:"" });
  const [cardErrors, setCardErrors] = useState<Record<string,string>>({});

  const saveProfile = () => {
    const e: Record<string,string> = {};
    if (!profile.name) e.name = "Name required";
    if (!profile.email||!/\S+@\S+\.\S+/.test(profile.email)) e.email = "Valid email required";
    setErrors(e);
    if (!Object.keys(e).length) { localStorage.setItem("qx_profile", JSON.stringify(profile)); toast("Profile saved!"); }
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) { toast("Please select an image file","error"); return; }
    if (file.size > 2*1024*1024) { toast("Image must be under 2MB","error"); return; }
    const reader = new FileReader();
    reader.onload = ev => { setAvatarPreview(ev.target?.result as string); toast("Photo updated!"); };
    reader.readAsDataURL(file);
  };

  const validateCard = () => {
    const e: Record<string,string> = {};
    if (!newCard.number||newCard.number.replace(/\s/g,"").length < 16) e.number="Enter 16-digit card number";
    if (!newCard.name) e.name="Required";
    if (!newCard.expiry||!/^\d{2}\/\d{2}$/.test(newCard.expiry)) e.expiry="Format: MM/YY";
    if (!newCard.cvc||newCard.cvc.length<3) e.cvc="3-4 digits";
    return e;
  };

  const addCard = () => {
    const e = validateCard(); setCardErrors(e);
    if (Object.keys(e).length) return;
    const last4 = newCard.number.replace(/\s/g,"").slice(-4);
    setCards(p => [...p, { id:Date.now(), last4, brand:"Card", expiry:newCard.expiry, name:newCard.name, isDefault:false }]);
    setShowAddCard(false); setNewCard({ number:"", name:"", expiry:"", cvc:"" });
    toast("Payment method added!");
  };

  const formatCardNum = (v: string) => v.replace(/\D/g,"").replace(/(.{4})/g,"$1 ").trim().slice(0,19);

  const plans = [
    { name:"Starter", price:"$29", features:["5 users","10 projects","Basic analytics","Email support"] },
    { name:"Pro", price:"$79", features:["25 users","Unlimited projects","Advanced AI","Priority support"], recommended:true },
    { name:"Enterprise", price:"$199", features:["Unlimited users","Custom integrations","Dedicated manager","SLA guarantee"] },
  ];

  return (
    <div>
      <div className="page-header"><div><div className="page-title">Settings</div><div className="page-sub">Manage your account preferences</div></div></div>
      <div className="settings-nav">
        {["profile","billing"].map(t=>(
          <div key={t} className={`settings-tab${tab===t?" active":""}`} onClick={()=>setTab(t)}>{t==="profile"?"👤 Profile":"💳 Billing"}</div>
        ))}
      </div>
      {tab==="profile" && (
        <div className="grid-2" style={{alignItems:"start"}}>
          <div className="card">
            <div className="card-title mb-3">Profile Photo</div>
            <div className="flex items-center gap-4 mb-4">
              <label style={{cursor:"pointer"}}>
                <div className="avatar-upload">
                  {avatarPreview ? <img src={avatarPreview} alt="" style={{width:"100%",height:"100%",objectFit:"cover",borderRadius:"50%"}} /> : <span>AM</span>}
                  <div className="avatar-overlay">📷</div>
                </div>
                <input type="file" accept="image/*" style={{display:"none"}} onChange={handleAvatarChange} />
              </label>
              <div>
                <div style={{fontSize:13,fontWeight:600}}>Alex Morgan</div>
                <div style={{fontSize:12,color:"var(--text3)"}}>Super Admin</div>
                <div style={{fontSize:11,color:"var(--text3)",marginTop:4}}>Click photo to change • Max 2MB</div>
              </div>
            </div>
          </div>
          <div className="card">
            <div className="card-title mb-3">Account Information</div>
            {([["name","Full Name","text"],["email","Email","email"],["company","Company","text"],["role","Role","text"]] as [string,string,string][]).map(([f,l,t])=>(
              <div className="form-group" key={f}>
                <label className="form-label">{l}</label>
                <input className="form-input" type={t} value={(profile as any)[f]} onChange={e=>setProfile(p=>({...p,[f]:e.target.value}))} />
                {errors[f]&&<div className="form-error">{errors[f]}</div>}
              </div>
            ))}
            <button className="btn btn-primary" onClick={saveProfile}>Save Changes</button>
          </div>
        </div>
      )}
      {tab==="billing" && (
        <div>
          <div className="card section-gap">
            <div className="flex items-center justify-between mb-3">
              <div><div className="card-title">Current Plan</div><div className="card-sub">You&apos;re on the <strong>{plan}</strong> plan — status: <span style={{color:subStatus==="Active"?"var(--green)":"var(--red)"}}>{subStatus}</span></div></div>
              {subStatus==="Active" && <button className="btn btn-danger btn-sm" onClick={()=>setShowCancelModal(true)}>Cancel Plan</button>}
              {subStatus==="Cancelled" && <button className="btn btn-primary btn-sm" onClick={()=>{setSubStatus("Active");toast("Subscription reactivated!");}}>Reactivate</button>}
            </div>
            <div className="grid-3">
              {plans.map(p => (
                <div key={p.name} className={`pricing-card${(p as any).recommended?" recommended":""}`}>
                  {(p as any).recommended && <div style={{fontSize:10,fontWeight:700,color:"var(--accent)",marginBottom:4,letterSpacing:1}}>✦ RECOMMENDED</div>}
                  <div style={{fontWeight:800,fontSize:16}}>{p.name}</div>
                  <div className="pricing-price">{p.price}<span className="pricing-period">/mo</span></div>
                  {p.features.map(f=><div key={f} className="pricing-feature"><span style={{color:"var(--green)"}}>✓</span>{f}</div>)}
                  <button className={`btn ${plan===p.name?"btn-secondary":"btn-primary"} w-full mt-3`} style={{justifyContent:"center"}}
                    onClick={()=>plan!==p.name&&setShowPlanModal(p.name)}>
                    {plan===p.name?"Current Plan":"Upgrade"}
                  </button>
                </div>
              ))}
            </div>
          </div>
          <div className="card">
            <div className="flex items-center justify-between mb-3">
              <div className="card-title">Payment Methods</div>
              <button className="btn btn-primary btn-sm" onClick={()=>setShowAddCard(true)}>+ Add Card</button>
            </div>
            {cards.map(c => (
              <div key={c.id} style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"12px",background:"var(--bg3)",borderRadius:8,marginBottom:8,border:"1px solid var(--border)"}}>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <div style={{width:36,height:24,background:"var(--bg4)",borderRadius:4,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:700,color:"var(--accent)"}}>VISA</div>
                  <div>
                    <div style={{fontWeight:600,fontSize:13}}>•••• •••• •••• {c.last4}</div>
                    <div style={{fontSize:11,color:"var(--text3)"}}>{c.name} · Expires {c.expiry}</div>
                  </div>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  {c.isDefault && <span className="badge badge-qualified">Default</span>}
                  {!c.isDefault && <button className="btn btn-ghost btn-xs" onClick={()=>{setCards(p=>p.map(x=>({...x,isDefault:x.id===c.id})));toast("Default updated");}}>Set default</button>}
                  {cards.length>1 && <button className="btn btn-danger btn-xs" onClick={()=>{if(c.isDefault){toast("Can't delete default card","error");return;}setCards(p=>p.filter(x=>x.id!==c.id));toast("Card removed");}}>✕</button>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {showPlanModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowPlanModal(null)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">Upgrade to {showPlanModal}</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowPlanModal(null)}>✕</button></div>
            <div className="modal-body"><p style={{fontSize:13,color:"var(--text2)"}}>You&apos;re about to upgrade from <strong>{plan}</strong> to <strong>{showPlanModal}</strong>. Your billing will be prorated.</p></div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setShowPlanModal(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={()=>{setPlan(showPlanModal!);setSubStatus("Active");setShowPlanModal(null);toast(`Upgraded to ${showPlanModal}!`);}}>Confirm Upgrade</button>
            </div>
          </div>
        </div>
      )}
      {showCancelModal && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowCancelModal(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title" style={{color:"var(--red)"}}>Cancel Subscription</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowCancelModal(false)}>✕</button></div>
            <div className="modal-body"><p style={{fontSize:13,color:"var(--text2)"}}>Are you sure you want to cancel? You&apos;ll retain access until the end of your billing period.</p></div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={()=>setShowCancelModal(false)}>Keep subscription</button>
              <button className="btn btn-danger" onClick={()=>{setSubStatus("Cancelled");setShowCancelModal(false);toast("Subscription cancelled","info");}}>Yes, cancel</button>
            </div>
          </div>
        </div>
      )}
      {showAddCard && (
        <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&setShowAddCard(false)}>
          <div className="modal">
            <div className="modal-header"><div className="modal-title">Add Payment Method</div><button className="btn btn-ghost btn-icon" onClick={()=>setShowAddCard(false)}>✕</button></div>
            <div className="modal-body">
              <div className="form-group"><label className="form-label">Card Number</label><input className="form-input" placeholder="1234 5678 9012 3456" maxLength={19} value={newCard.number} onChange={e=>setNewCard(p=>({...p,number:formatCardNum(e.target.value)}))} />{cardErrors.number&&<div className="form-error">{cardErrors.number}</div>}</div>
              <div className="form-group"><label className="form-label">Cardholder Name</label><input className="form-input" placeholder="Alex Morgan" value={newCard.name} onChange={e=>setNewCard(p=>({...p,name:e.target.value}))} />{cardErrors.name&&<div className="form-error">{cardErrors.name}</div>}</div>
              <div className="grid-2">
                <div className="form-group"><label className="form-label">Expiry</label><input className="form-input" placeholder="MM/YY" maxLength={5} value={newCard.expiry} onChange={e=>setNewCard(p=>({...p,expiry:e.target.value.replace(/[^\d/]/g,"")}))} />{cardErrors.expiry&&<div className="form-error">{cardErrors.expiry}</div>}</div>
                <div className="form-group"><label className="form-label">CVC</label><input className="form-input" placeholder="123" maxLength={4} type="password" value={newCard.cvc} onChange={e=>setNewCard(p=>({...p,cvc:e.target.value.replace(/\D/g,"")}))} />{cardErrors.cvc&&<div className="form-error">{cardErrors.cvc}</div>}</div>
              </div>
            </div>
            <div className="modal-footer"><button className="btn btn-secondary" onClick={()=>setShowAddCard(false)}>Cancel</button><button className="btn btn-primary" onClick={addCard}>Add Card</button></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [authPage, setAuthPage] = useState("login");
  const [authed, setAuthed] = useState(false);
  const [page, setPage] = useState("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [notifications, setNotifications] = useState(initialNotifications);
  const { toasts, add: toast } = useToast();

  useEffect(() => {
    // check session on mount
    const session = localStorage.getItem("qx_session");
    if (session) setAuthed(true);
    const theme = localStorage.getItem("qx_theme");
    if (theme === "light") setDarkMode(false);
  }, []);

  useEffect(() => {
    document.documentElement.className = darkMode ? "" : "light-mode";
    localStorage.setItem("qx_theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  const logout = () => { localStorage.removeItem("qx_session"); setAuthed(false); setAuthPage("login"); };
  const login = () => setAuthed(true);
  const navigate = (p: string) => { if (p==="billing") { setPage("settings"); } else setPage(p); };

  if (!authed) {
    if (authPage==="register") return <RegisterPage onNavigate={setAuthPage} />;
    if (authPage==="forgot") return <ForgotPage onNavigate={setAuthPage} />;
    return <LoginPage onLogin={login} onNavigate={setAuthPage} />;
  }

  const renderPage = () => {
    switch(page) {
      case "dashboard": return <DashboardPage />;
      case "analytics": return <AnalyticsPage />;
      case "crm": return <CRMPage toast={toast} />;
      case "finance": return <FinancePage toast={toast} />;
      case "projects": return <ProjectsPage toast={toast} />;
      case "kanban": return <KanbanPage />;
      case "calendar": return <CalendarPage toast={toast} />;
      case "chat": return <ChatPage />;
      case "email": return <EmailPage toast={toast} />;
      case "settings": return <SettingsPage toast={toast} />;
      default: return <DashboardPage />;
    }
  };

  return (
    <>
      <div className="app-shell">
        {mobileSidebar && <div className="overlay" onClick={()=>setMobileSidebar(false)} />}
        <Sidebar
          active={page}
          onNav={(p: string)=>{setPage(p);setMobileSidebar(false);}}
          collapsed={sidebarCollapsed}
          onToggle={()=>setSidebarCollapsed(p=>!p)}
          mobileOpen={mobileSidebar}
          notifications={notifications}
        />
        <div className={`main-area${sidebarCollapsed?" collapsed":""}`}>
          <Header
            onMenuToggle={()=>{ if(typeof window!=="undefined"&&window.innerWidth<=768) setMobileSidebar(p=>!p); else setSidebarCollapsed(p=>!p); }}
            page={page}
            darkMode={darkMode}
            toggleDark={()=>setDarkMode(p=>!p)}
            onLogout={logout}
            onNav={navigate}
            notifications={notifications}
            setNotifications={setNotifications}
          />
          <div className="page-content">
            {renderPage()}
          </div>
        </div>
      </div>
      <ToastContainer toasts={toasts} />
    </>
  );
}
