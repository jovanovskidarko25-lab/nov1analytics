import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Quantix UI — Admin Analytics Hub",
  description: "AI-powered SaaS analytics dashboard by Quantix Labs",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
